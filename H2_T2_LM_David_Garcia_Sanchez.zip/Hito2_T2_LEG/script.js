// Función para cargar el archivo XML
function cargarXML() {
    return new Promise((resolve, reject) => {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                resolve(this.responseXML);
            }
        };
        xhttp.open("GET", "pedidos.xml", true);
        xhttp.send();
    });
}

// Función para generar la tabla de clientes
function generarTablaClientes(xmlDoc) {
    var clientesTable = document.getElementById("clientes-table");
    var clientes = xmlDoc.getElementsByTagName("cliente");
    var tableContent = "<h3>Información de Clientes</h3><table><tr><th>Nombre</th><th>Apellidos</th><th>Teléfono</th><th>Dirección</th><th>Correo Electrónico</th><th>Fecha de Inclusión</th></tr>";
    for (var i = 0; i < clientes.length; i++) {
        var nombre = clientes[i].getElementsByTagName("nombre")[0].childNodes[0].nodeValue;
        var apellidos = clientes[i].getElementsByTagName("apellidos")[0].childNodes[0].nodeValue;
        var telefono = clientes[i].getElementsByTagName("telefono")[0].childNodes[0].nodeValue;
        var direccion = obtenerDireccion(clientes[i]);
        var correo = clientes[i].getElementsByTagName("correo_electronico")[0].childNodes[0].nodeValue;
        var fechaInclusion = clientes[i].getElementsByTagName("fecha_inclusion")[0].childNodes[0].nodeValue;
        tableContent += "<tr><td>" + nombre + "</td><td>" + apellidos + "</td><td>" + telefono + "</td><td>" + direccion + "</td><td>" + correo + "</td><td>" + fechaInclusion + "</td></tr>";
    }
    tableContent += "</table>";
    clientesTable.innerHTML = tableContent;
}

// Función para generar la tabla de pedidos
function generarTablaPedidos(xmlDoc) {
    var pedidosTable = document.getElementById("pedidos-table");
    var pedidos = xmlDoc.getElementsByTagName("pedido");
    var tableContent = "<h3>Información de Pedidos</h3><table><tr><th>Número de Pedido</th><th>Fecha de Compra</th><th>Fecha de Entrega</th><th>Total de Factura</th></tr>";
    for (var i = 0; i < pedidos.length; i++) {
        var numeroPedido = pedidos[i].getElementsByTagName("numero_pedido")[0].childNodes[0].nodeValue;
        var fechaCompra = pedidos[i].getElementsByTagName("fecha_compra")[0].childNodes[0].nodeValue;
        var fechaEntrega = pedidos[i].getElementsByTagName("fecha_entrega")[0].childNodes[0].nodeValue;
        var totalFactura = parseFloat(pedidos[i].getElementsByTagName("total_factura")[0].childNodes[0].nodeValue);
        tableContent += "<tr><td>" + numeroPedido + "</td><td>" + fechaCompra + "</td><td>" + fechaEntrega + "</td><td>" + totalFactura.toFixed(2) + "</td></tr>";
    }
    tableContent += "</table>";
    pedidosTable.innerHTML = tableContent;
}

// Función para crear la factura de un cliente específico
function generarFacturaCliente(xmlDoc, nombreCliente) {
    var cliente = null;
    var clientes = xmlDoc.getElementsByTagName("cliente");
    for (var i = 0; i < clientes.length; i++) {
        var nombre = clientes[i].getElementsByTagName("nombre")[0].childNodes[0].nodeValue;
        if (nombre === nombreCliente) {
            cliente = clientes[i];
            break;
        }
    }
    if (cliente) {
        var facturaCliente = document.getElementById("factura-cliente");
        var facturaContent = "<h3>Factura</h3>";
        facturaContent += "<table><tr><th>Número de Pedido</th><th>Fecha de Compra</th><th>Fecha de Entrega</th><th>Total de Factura</th><th>Cliente</th><th>Dirección</th><th>Correo Electrónico</th><th>Productos</th></tr>";
        var pedidos = cliente.getElementsByTagName("pedido");
        for (var i = 0; i < pedidos.length; i++) {
            var numeroPedido = pedidos[i].getElementsByTagName("numero_pedido")[0].childNodes[0].nodeValue;
            var fechaCompra = pedidos[i].getElementsByTagName("fecha_compra")[0].childNodes[0].nodeValue;
            var fechaEntrega = pedidos[i].getElementsByTagName("fecha_entrega")[0].childNodes[0].nodeValue;
            var totalFactura = parseFloat(pedidos[i].getElementsByTagName("total_factura")[0].childNodes[0].nodeValue);
            var direccion = obtenerDireccion(cliente);
            var correo = cliente.getElementsByTagName("correo_electronico")[0].childNodes[0].nodeValue;
            facturaContent += "<tr><td>" + numeroPedido + "</td><td>" + fechaCompra + "</td><td>" + fechaEntrega + "</td><td>" + totalFactura.toFixed(2) + "</td><td>" + nombreCliente + "</td><td>" + direccion + "</td><td>" + correo + "</td><td>";
            var productos = pedidos[i].getElementsByTagName("producto");
            for (var j = 0; j < productos.length; j++) {
                var nombreProducto = productos[j].getElementsByTagName("nombre")[0].childNodes[0].nodeValue;
                var referenciaProducto = productos[j].getElementsByTagName("referencia")[0].childNodes[0].nodeValue;
                var precioProducto = parseFloat(productos[j].getElementsByTagName("precio")[0].childNodes[0].nodeValue);
                var unidadesProducto = parseInt(productos[j].getElementsByTagName("unidades")[0].childNodes[0].nodeValue);
                facturaContent += nombreProducto + " (Ref: " + referenciaProducto + ") - Precio: " + precioProducto.toFixed(2) + " - Unidades: " + unidadesProducto + "<br>";
            }
            facturaContent += "</td></tr>";
        }
        facturaContent += "</table>";
        facturaCliente.innerHTML = facturaContent;
    } else {
        console.log("Cliente no encontrado.");
    }
}

// Función para obtener la dirección de un cliente
function obtenerDireccion(cliente) {
    var direccion = "";
    var calle = cliente.getElementsByTagName("calle")[0].childNodes[0].nodeValue;
    var ciudad = cliente.getElementsByTagName("ciudad")[0].childNodes[0].nodeValue;
    var codigoPostal = cliente.getElementsByTagName("codigo_postal")[0].childNodes[0].nodeValue;
    var provincia = cliente.getElementsByTagName("provincia")[0].childNodes[0].nodeValue;
    direccion = calle + ", " + ciudad + ", CP: " + codigoPostal + ", " + provincia;
    return direccion;
}

// Función para mostrar los productos vendidos en un trimestre específico de un año específico
function mostrarProductosPorTrimestre(xmlDoc, trimestre, año, idTabla) {
    var productosTable = document.getElementById(idTabla);
    var pedidos = xmlDoc.getElementsByTagName("pedido");
    var tableContent = "<table><tr><th>Producto</th><th>Referencia</th><th>Precio</th><th>Unidades</th></tr>";
    for (var i = 0; i < pedidos.length; i++) {
        var fechaCompra = pedidos[i].getElementsByTagName("fecha_compra")[0].childNodes[0].nodeValue;
        var añoPedido = parseInt(fechaCompra.substring(0, 4));
        var mesPedido = parseInt(fechaCompra.substring(5, 7));
        if (añoPedido === año && Math.ceil(mesPedido / 3) === trimestre) {
            var productos = pedidos[i].getElementsByTagName("producto");
            for (var j = 0; j < productos.length; j++) {
                var producto = productos[j];
                var nombreProducto = producto.getElementsByTagName("nombre")[0].childNodes[0].nodeValue;
                var referenciaProducto = producto.getElementsByTagName("referencia")[0].childNodes[0].nodeValue;
                var precioProducto = parseFloat(producto.getElementsByTagName("precio")[0].childNodes[0].nodeValue);
                var unidadesProducto = parseInt(producto.getElementsByTagName("unidades")[0].childNodes[0].nodeValue);
                tableContent += "<tr><td>" + nombreProducto + "</td><td>" + referenciaProducto + "</td><td>" + precioProducto.toFixed(2) + "</td><td>" + unidadesProducto + "</td></tr>";
            }
        }
    }
    tableContent += "</table>";
    productosTable.innerHTML = tableContent;
}

// Llamada para cargar el XML y generar las tablas
cargarXML().then(xmlDoc => {
    generarTablaClientes(xmlDoc);
    generarTablaPedidos(xmlDoc);
    generarFacturaCliente(xmlDoc, "Juan");
    mostrarProductosPorTrimestre(xmlDoc, 1, 2021, "productos-table-2021");
    mostrarProductosPorTrimestre(xmlDoc, 1, 2022, "productos-table-2022");
});